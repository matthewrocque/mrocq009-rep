package com.example.lab3simplecalculator;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    private enum Operator {none, add, subtract, multiply, divide};
    private double data1=0, data2=0;
    private Operator optr = Operator.none;

    public void btn01Click(View view){
        TextView eText = (TextView)findViewById(R.id.resultEdit);
        eText.setText(eText.getText()+"1");
    }
    public void btn02Click(View view){
        TextView eText = (TextView)findViewById(R.id.resultEdit);
        eText.setText(eText.getText()+"2");
    }
    public void btn03Click(View view){
        TextView eText = (TextView)findViewById(R.id.resultEdit);
        eText.setText(eText.getText()+"3");
    }
    public void btn04Click(View view){
        TextView eText = (TextView)findViewById(R.id.resultEdit);
        eText.setText(eText.getText()+"4");
    }
    public void btn05Click(View view){
        TextView eText = (TextView)findViewById(R.id.resultEdit);
        eText.setText(eText.getText()+"5");
    }
    public void btn06Click(View view){
        TextView eText = (TextView)findViewById(R.id.resultEdit);
        eText.setText(eText.getText()+"6");
    }
    public void btn07Click(View view){
        TextView eText = (TextView)findViewById(R.id.resultEdit);
        eText.setText(eText.getText()+"7");
    }
    public void btn08Click(View view){
        TextView eText = (TextView)findViewById(R.id.resultEdit);
        eText.setText(eText.getText()+"8");
    }
    public void btn09Click(View view){
        TextView eText = (TextView)findViewById(R.id.resultEdit);
        eText.setText(eText.getText()+"9");
    }
    public void btnAddClick(View view){
        optr=Operator.add;
        TextView eText = (TextView)findViewById(R.id.resultEdit);
        data1 = Double.parseDouble(eText.getText().toString());
        eText.setText("");
    }
    public void btnSubClick(View view){
        optr=Operator.subtract;
        TextView eText = (TextView)findViewById(R.id.resultEdit);
        data1 = Double.parseDouble(eText.getText().toString());
        eText.setText("");
    }
    public void btnDivClick(View view){
        optr=Operator.divide;
        TextView eText = (TextView)findViewById(R.id.resultEdit);
        data1 = Double.parseDouble(eText.getText().toString());
        eText.setText("");
    }
    public void btnMultClick(View view){
        optr=Operator.multiply;
        TextView eText = (TextView)findViewById(R.id.resultEdit);
        data1 = Double.parseDouble(eText.getText().toString());
        eText.setText("");
    }
    public void btnDotClick(View view) {
        TextView eText = (TextView) findViewById(R.id.resultEdit);
        eText.setText(eText.getText() + ".");
    }
    public void btnClrClick(View view) {
        TextView eText = (TextView) findViewById(R.id.resultEdit);
        eText.setText("");
    }
    public void btn00Click(View view){
        TextView eText = (TextView) findViewById(R.id.resultEdit);
        eText.setText(eText.getText() + "0");
    }
    public void btnResultClick(View view){
        if(optr!=Operator.none){
            TextView eText = (TextView)findViewById(R.id.resultEdit);
            data2 = Double.parseDouble(eText.getText().toString());
            double result = 0;
            if(optr == Operator.add){
                result = data1 + data2;
            }
            else if(optr == Operator.subtract){
                result = data1 - data2;
            }
            else if(optr == Operator.divide){
                result = data1 / data2;
            }
            else if(optr == Operator.multiply){
                result = data1 * data2;
            }
            optr = Operator.none;
            data1 = result;
            if((result - (int) result != 0)){
                eText.setText(String.valueOf(result));
            }
            else{
                eText.setText(String.valueOf((int) result));
            }
        }
    }
}